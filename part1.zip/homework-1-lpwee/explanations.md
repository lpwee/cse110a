# HW1-w26

## Part 1

### Correctness: Describe how your scanner extensions implement the required behavior, including any edge cases you handled.

Started by brainstorming and creating a checklist of the kind of edge cases that will be faced, then marking them when I have solved them:

- [x] two decimal points (return error when decimal > 1)
- [x] leading decimal point (first NUMS check)
- [x] semicolons 
- [x] trailing . (no number behind decimal)
- [x] ID containing numbers
- [x] INCR ++
- [x] floats starting with .


### Conceptual: Explain how your implementation aligns with the naive scanner design.

Hardcoded logic handling case by case, naively scanning through every possible case to eventually identify which token type is being scanned.

### Experiments: Report your timing results for 10/100/1000/10000 tokens and how you ran them.

- test10   : 0.00008s 
- test100  : 0.0007s
- test1000 : 0.009s
- test10000: 0.767s 

### Explanation: Summarize your implementation choices and discuss performance.

Each token is handled by an explicit `if` branch that checks the first character and then consumes characters in a `while` loop:

- SEMI:
Single-character check for `;`.
- INCR / ADD: 
On seeing `+`, consume all consecutive `+` characters. If the result is `++` return INCR, if `+` return ADD, otherwise raise an exception.
- ID: 
Triggered by a letter. The first character must be in `CHARS` (letters only), then subsequent characters are consumed from `NUM_CHARS` (letters and digits), allowing IDs like `abc123` but not `123abc`.
- NUM: 
Triggered by a digit or `.`. Consumes digits, then optionally a `.` followed by more digits. If `.` has no digit after it, the `.` is put back onto the stream. If the branch was entered on `.` but no digit followed, an exception is raised (bare `.` is invalid). This handles integers (`123`), decimals (`3.14`), leading-dot floats (`.5`), and rejects trailing-dot (`56.`).

## Part 2

### Submission: Summarize what you submitted in tokens.py and where it lives in your repo.

Expanded the tokens.py file to include the other tokens as required by the README.md, alongside the appropriate regex to scan and identify them. Made changes to existing code to imporve their robustness.

### Written Report: Describe your RE definitions and include timing results for the EM scanner.

Converted all strings to raw strings `r` so that the escape characters are not ignored.

- ID - `r"[a-zA-Z]+[a-zA-Z0-9]*"`
Matches one or more letters followed by zero or more letters or digits. This ensures the ID cannot start with a digit.
- NUM `r"[0-9]*\.?[0-9]+"`
Matches zero or more digits followed by an optional decimal point, allowing floating point numbers to start with only a decimal point. Then matches one or more digits after the decimal point to ensure either the number contains digits or there are digits after the decimal.
- IGNORE `r" |\n"`
Matches a single space or newline character.
- HNUM `r"0x[a-fA-F0-9]+"`
Matches a hex number starting with `0x` followed by one or more hex digits (0-9, a-f, case insensitive).
- INCR `r"\+\+"`
Matches the literal string `++`. The `+` characters are escaped because `+` is a regex quantifier.
- PLUS `r"\+"
 Matches a single `+`.
- MULT `r"\*"`
Matches a single `*`. The `*` is escaped because it is a regex quantifier.
- SEMI `r";"`
Matches a single `;`.
- LPAREN / RPAREN `r"\("` / `r"\)"`
Match `(` and `)`. Escaped because parentheses are regex grouping operators.
- LBRACE / RBRACE `r"\{"` / `r"\}"` 
Match `{` and `}`. Escaped because braces are regex quantifier delimiters.
- ASSIGN `r"="`: 
Matches a singel `=`.

- Keywords (IF, ELSE, WHILE, INT, FLOAT)
Given a token action on the ID token so that they are identified as the keywoards after passing the scan as an ID token.

### Testing and Verification: Explain how you tested part2.txt (locally and on Gradescope) and report the outcomes.

EM Scanner test timings:
- test10  : 0.021030426025390625s
- test100 : 2.2235634326934814s
- test1000: really long

Submitted mulitple times on gradescope to eventually get all test cases passing.

### Debugging and Iteration: Describe any failures you encountered and how you resolved them (include submission iterations if relevant).

Initially, I listed keywords like `if`, `else`, `while`, `int`, and `float` as their own entries in the tokens list. 
However, because `ID` appears first and the EM scanner takes the first match, keywords were always matched as ID. 

Fixed by adding a `keyword_check` function that that acts as the token action to seacrh through the scanned ID to see if it in the list of reserved keywords, nd return the appropriate token/lexeme if it is a keyword.

## Part 3

### Correctness: Describe how your SOS scanner implements the required behavior, including tricky cases.

The SOS scanner uses `re.match` to match each token pattern at the start of the input string. For each call to `token()`, it tries every token pattern once, collects all matches, and picks the longest one.

This handles tricky cases like `++` vs `+` and `0xff` vs `0`, where the wrong token is a subset of a longer token. Keywords are handled by the same `keyword_check` token action from Part 2.

### Conceptual: Explain how your design matches the SOS scanning approach.

The SOS scanner matches the SOS design by using `re.match` instead of `re.fullmatch`. Since `re.match` anchors at the start of the string and returns the longest match the pattern can produce, there is no need to iterate over every possible substring length as the EM scanner does. Each token pattern is tried exactly once per call to `token()`, and the longest match among all tokens is selected. This eliminates the inner substring loop of the EM scanner entirely.

### Experiments: Report timings for 10/100/1000/10000 tokens and compare to the EM scanner.

SOS Scanner timings:
- test10:    0.0003s
- test100:   0.0017s
- test1000:  0.015s
- test10000: 0.275s

EM Scanner timings:
- test10:    0.021s
- test100:   2.224s
- test1000:  really long
- test10000: really really long

The SOS scanner is much faster than the EM scanner

### Explanation: Summarize implementation details and performance observations.

The SOS scanner calls `re.match(pattern, self.istring)` for every token pattern, collects matches, and picks the longest via `max()` on match length. 
Then it chops the longest token out and runs re.match for each token again, also running the token action for each token picked.

The number of operations to be completed by the EM Scanner is length x no. of tokens, as it scans through each substring with one char removed and multiplied by the number of tokens as it checks through all tokens at each length.

Whereas the SOS scanner saves time by only checking each token once, making it take only (number of tokens) time.

EM Scanner is O(n*t) where n is input length and t is number of tokens, whereas SOS Scanner is O(t) per token. This difference is observed in the larger input sizes.

## Part 4

### Correctness: Describe how your NG scanner implements the required behavior, including tricky cases.

The NG scanner builds one combined regex with named groups and uses a single `re.match` call per token, which evaluates all token regex patterns in one call. A tricky case to consider is token ordering.

HNUM is placed before NUM so that `0xff` matches as HNUM rather than NUM matching just `0`. INCR is placed before PLUS so that `++` matches as INCR rather than two PLUS tokens.

### Conceptual: Explain how your design matches the NG scanning approach.

The NG scanner combines all token patterns into a single regex using named groups: `(?P<ID>...)|(?P<HNUM>...)|(?P<NUM>...)|...`. Each call to `token()` performs one `re.match` on the whole combined pattern, and `m.lastgroup` identifies which token matched. This means only one regex match is needed per token, compared to the SOS scanner which tries every token pattern individually.

### Experiments: Report timings for 10/100/1000/10000 tokens and compare to the SOS scanner.

NG Scanner timings:
- test10:    0.0002s
- test100:   0.0003s
- test1000:  0.002s
- test10000: 0.168s

SOS Scanner timings:
- test10:    0.0003s
- test100:   0.0017s
- test1000:  0.015s
- test10000: 0.275s

The NG scanner is faster across all input sizes.

### Explanation: Summarize implementation details and performance observations.

In `__init__`, the scanner iterates through the tokens list, building a named group `(?P<name>pattern)` for each token and storing the token type and action in a dictionary keyed by group name. The combined pattern is compiled once with `re.compile`.

In `token()`, the scanner loops until it finds a non-IGNORE token or the input is empty. Each iteration calls `self.combined.match(self.istring)`, reads `m.lastgroup` to identify the matched token, looks up the action, and chops the matched text from the input.

The performance gain over the SOS scanner comes from reducing the number of regex operations per token from t (number of token patterns) to 1.

