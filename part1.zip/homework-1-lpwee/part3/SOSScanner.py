import re
from functools import reduce
from time import time
import argparse
import pdb
import sys
sys.path.append("../part2/")
from tokens import tokens,Token,Lexeme
from typing import Callable,List,Tuple,Optional


# No line number this time
class ScannerException(Exception):
    pass

class SOSScanner:
    def __init__(self, tokens: List[Tuple[Token,str,Callable[[Lexeme],Lexeme]]]) -> None:
        self.tokens = tokens

    def input_string(self, input_string:str) -> None:
        self.istring = input_string

    def token(self) -> Optional[Lexeme]:
        while True:
            if len(self.istring) == 0:
                return None

            matches = []

            # Try each token pattern once using re.match
            for t in self.tokens:
                (tok, pattern, token_action) = t[0], t[1], t[2]
                m = re.match(pattern, self.istring)
                if m is not None:
                    matches.append((tok, m, token_action))

            if len(matches) == 0:
                raise ScannerException()

            # Pick the longest match
            longest = max(matches, key=lambda m: len(m[1][0]))

            tok    = longest[0]
            mtch   = longest[1]
            action = longest[2]
            value_found = mtch[0]
            ret = action(Lexeme(tok, value_found))

            chop = len(value_found)
            self.istring = self.istring[chop:]

            if ret.token != Token.IGNORE:
                return ret

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('file_name', type=str)
    parser.add_argument('--verbose', '-v', action='store_true')
    args = parser.parse_args()
    
    f = open(args.file_name)    
    f_contents = f.read()
    f.close()

    verbose = args.verbose

    s = SOSScanner(tokens)
    s.input_string(f_contents)

    start = time()
    while True:
        t = s.token()
        if t is None:
            break
        if (verbose):
            print(t)
    end = time()
    print("time to parse (seconds): ",str(end-start))    
