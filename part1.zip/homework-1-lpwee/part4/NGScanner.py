import re
from functools import reduce
from time import time
import argparse
import pdb
import sys
sys.path.append("../part2/")
from tokens import tokens,Token,Lexeme
from typing import Callable,List,Tuple,Optional

# No line number this time
class ScannerException(Exception):
    pass

class NGScanner:
    def __init__(self, tokens: List[Tuple[Token,str,Callable[[Lexeme],Lexeme]]]) -> None:
        self.tokens = tokens

        # Build one combined RE with named groups and an action lookup
        self.actions = {}
        parts = []
        for tok, pattern, action in tokens:
            name = tok.value
            parts.append(f"(?P<{name}>{pattern})")
            self.actions[name] = (tok, action)
        self.combined = re.compile("|".join(parts))

    def input_string(self, input_string:str) -> None:
        self.istring = input_string

    def token(self) -> Optional[Lexeme]:
        while True:
            if len(self.istring) == 0:
                return None

            m = self.combined.match(self.istring)
            if m is None:
                raise ScannerException()

            group_name = m.lastgroup
            tok, action = self.actions[group_name]
            value_found = m[0]
            ret = action(Lexeme(tok, value_found))

            self.istring = self.istring[len(value_found):]

            if ret.token != Token.IGNORE:
                return ret

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('file_name', type=str)
    parser.add_argument('--verbose', '-v', action='store_true')
    args = parser.parse_args()
    
    f = open(args.file_name)    
    f_contents = f.read()
    f.close()

    verbose = args.verbose

    s = NGScanner(tokens)
    s.input_string(f_contents)

    start = time()
    while True:
        t = s.token()
        if t is None:
            break
        if (verbose):
            print(t)
    end = time()
    print("time to parse (seconds): ",str(end-start))    
